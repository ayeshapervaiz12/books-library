import react from 'react'
import  Navbar from './navbar';
import Section from './section';
const App= () => {
return(
  
  <div>
    <Navbar/>
    <Section/>
  </div>
)




}
export default App